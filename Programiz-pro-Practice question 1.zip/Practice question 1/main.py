import math
def calculate_area(shape, dimensions):
    if shape == "rectangle":
        length, width = dimensions
        return length * width
    elif shape == "circle":
        radius, = dimensions
        return math.pi * radius ** 2
    else:
        raise ValueError(f"Invalid shape: {shape}")

print("Note: All dimensions entered will be displayed in centimeters (cm).")

shape = input("Enter the shape (rectangle/circle): ").strip().lower()

if shape == "rectangle":
    length = float(input("Enter the length of the rectangle in cm: "))
    width = float(input("Enter the width of the rectangle in cm: "))
    dimensions = (length, width)
elif shape == "circle":
    radius = float(input("Enter the radius of the circle in cm: "))
    dimensions = (radius,)
else:
    raise ValueError(f"Invalid shape: {shape}")

area = calculate_area(shape, dimensions)

print(f"The area of the {shape} is: {area} square cm")